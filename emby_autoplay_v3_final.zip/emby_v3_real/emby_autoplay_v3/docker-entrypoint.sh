#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${APP_DIR:-/app}"
if [[ ! -f "${APP_DIR}/emby_webapp.py" && -f "${SCRIPT_DIR}/emby_webapp.py" ]]; then
  APP_DIR="${SCRIPT_DIR}"
fi
WEB_APP="${APP_DIR}/emby_webapp.py"
CLI_APP="${APP_DIR}/emby_autoplay.py"
RUN_MODE="${RUN_MODE:-web}"
SCHEDULE_TIME="${SCHEDULE_TIME:-07:00}"
PLAY_DURATION_SECONDS="${PLAY_DURATION_SECONDS:-300}"
RANDOM_SLEEP_SECONDS="${RANDOM_SLEEP_SECONDS:-3600}"
LOG_DIR="${LOG_DIR:-/logs}"
CONFIG_DIR="${CONFIG_DIR:-/config}"
SERVERS_FILE="${SERVERS_FILE:-${CONFIG_DIR}/servers.json}"
LOG_FILE="${LOG_FILE:-${LOG_DIR}/emby_autoplay.log}"
WEB_HOST="${WEB_HOST:-0.0.0.0}"
WEB_LISTEN_PORT="${WEB_LISTEN_PORT:-8080}"

mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
mkdir -p "$LOG_DIR" "$CONFIG_DIR" 2>/dev/null || true

ts() { date '+%Y-%m-%d %H:%M:%S %z'; }
log() { echo "[$(ts)] [entrypoint] $*" | tee -a "$LOG_FILE"; }

validate_runtime_config() {
  python - "$SCHEDULE_TIME" "$PLAY_DURATION_SECONDS" "$RANDOM_SLEEP_SECONDS" "$WEB_LISTEN_PORT" <<'PY'
from __future__ import annotations
import re, sys

schedule, duration, random_sleep, web_port = sys.argv[1:5]
if not re.fullmatch(r"[0-2][0-9]:[0-5][0-9]", schedule):
    raise SystemExit(f"SCHEDULE_TIME 格式错误：{schedule}，应为 HH:MM，例如 07:00。")
hour, minute = map(int, schedule.split(':', 1))
if hour > 23 or minute > 59:
    raise SystemExit(f"SCHEDULE_TIME 超出范围：{schedule}。")
for name, value in (("PLAY_DURATION_SECONDS", duration), ("RANDOM_SLEEP_SECONDS", random_sleep)):
    try:
        parsed = int(value)
    except ValueError:
        raise SystemExit(f"{name} 必须是整数，当前值：{value}")
    if parsed < 0:
        raise SystemExit(f"{name} 不能为负数，当前值：{value}")
try:
    port = int(web_port)
except ValueError:
    raise SystemExit(f"WEB_LISTEN_PORT 必须是整数，当前值：{web_port}")
if not (1 <= port <= 65535):
    raise SystemExit(f"WEB_LISTEN_PORT 超出范围：{web_port}")
PY
}

if ! validate_runtime_config 2>/tmp/emby_autoplay_validate.err; then
  cat /tmp/emby_autoplay_validate.err | tee -a "$LOG_FILE"
  exit 2
fi

case "$RUN_MODE" in
  web|daemon)
    log "启动网页管理服务（Hills 模式）。端口=${WEB_LISTEN_PORT}；每天 ${SCHEDULE_TIME} 触发，随机等待 0-${RANDOM_SLEEP_SECONDS} 秒。"
    exec python "$WEB_APP" --host "$WEB_HOST" --port "$WEB_LISTEN_PORT"
    ;;
  once)
    log "执行一次多服务器顺序播放（Hills 模式）。配置文件：${SERVERS_FILE}。"
    exec python "$WEB_APP" --once
    ;;
  cli-once)
    log "执行单服务器 CLI 播放（Hills 模式）。读取环境变量 EMBY_URL / EMBY_USERNAME / EMBY_PASSWORD。"
    exec python "$CLI_APP" --duration "$PLAY_DURATION_SECONDS" --random-sleep "$RANDOM_SLEEP_SECONDS"
    ;;
  *)
    log "RUN_MODE 不支持：$RUN_MODE。可选值：web、daemon、once、cli-once。"
    exit 2
    ;;
esac
