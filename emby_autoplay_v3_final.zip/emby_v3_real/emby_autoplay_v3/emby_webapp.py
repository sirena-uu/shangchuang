#!/usr/bin/env python3
"""
Emby 多服务器网页管理与顺序保号服务
- macOS 简约风格界面
- 中英文切换
- 单页应用，状态自动刷新
- 弹窗表单、连接测试
- 实时日志
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import random
import secrets
import sys
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from flask import Flask, Response, jsonify, redirect, request, url_for

from emby_autoplay import Config, HillsEmbyPlayer, log as player_log

DATA_DIR = Path(os.getenv("CONFIG_DIR", "/config"))
LOG_DIR = Path(os.getenv("LOG_DIR", "/logs"))
SERVERS_FILE = Path(os.getenv("SERVERS_FILE", str(DATA_DIR / "servers.json")))
APP_LOG_FILE = Path(os.getenv("LOG_FILE", str(LOG_DIR / "emby_autoplay.log")))

app = Flask(__name__)
app.secret_key = os.getenv("WEB_SECRET_KEY") or secrets.token_hex(24)

playback_lock = threading.Lock()
state_lock = threading.Lock()
playback_state: Dict[str, Any] = {
    "running": False,
    "trigger": None,
    "started_at": None,
    "finished_at": None,
    "current_server": None,
    "last_message": "服务已启动，等待任务。",
    "last_result": None,
    "history": [],
    "next_schedule_ts": None,
}


@dataclass
class ServerItem:
    id: str
    name: str
    base_url: str
    username: str
    password: str
    parent_id: str = ""
    enabled: bool = True
    verify_tls: bool = True
    interval_days: int = 1          # 每隔多少天运行一次，1=每天，2=每2天，以此类推
    time_window_start: str = ""     # 当天允许运行的开始时间，格式 "HH:MM"，空=不限
    time_window_end: str = ""       # 当天允许运行的结束时间，格式 "HH:MM"，空=不限
    last_run_date: str = ""         # 上次实际运行日期，格式 "YYYY-MM-DD"，用于间隔计算

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ServerItem":
        return cls(
            id=str(data.get("id") or uuid.uuid4().hex),
            name=str(data.get("name") or "未命名服务器"),
            base_url=str(data.get("base_url") or "").rstrip("/"),
            username=str(data.get("username") or ""),
            password=str(data.get("password") or ""),
            parent_id=str(data.get("parent_id") or ""),
            enabled=bool(data.get("enabled", True)),
            verify_tls=bool(data.get("verify_tls", True)),
            interval_days=int(data.get("interval_days") or 1),
            time_window_start=str(data.get("time_window_start") or ""),
            time_window_end=str(data.get("time_window_end") or ""),
            last_run_date=str(data.get("last_run_date") or ""),
        )


def app_log(message: str) -> None:
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [web] {message}"
    print(line, flush=True)
    try:
        APP_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with APP_LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def update_state(**kwargs: Any) -> None:
    with state_lock:
        playback_state.update(kwargs)


def add_history(row: Dict[str, Any]) -> None:
    with state_lock:
        history = list(playback_state.get("history") or [])
        history.insert(0, row)
        playback_state["history"] = history[:100]


def load_servers() -> List[ServerItem]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not SERVERS_FILE.exists():
        return []
    data = json.loads(SERVERS_FILE.read_text(encoding="utf-8") or "[]")
    if not isinstance(data, list):
        return []
    return [ServerItem.from_dict(x) for x in data]


def save_servers(servers: List[ServerItem]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    payload = [asdict(s) for s in servers]
    tmp = SERVERS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(SERVERS_FILE)
    try:
        SERVERS_FILE.chmod(0o600)
    except OSError:
        pass


def server_should_run_today(server: "ServerItem") -> bool:
    """判断该服务器今天是否应该运行（基于 interval_days 和 last_run_date）。"""
    if server.interval_days <= 1:
        return True
    if not server.last_run_date:
        return True
    try:
        last = datetime.strptime(server.last_run_date, "%Y-%m-%d").date()
        today = datetime.now().date()
        return (today - last).days >= server.interval_days
    except ValueError:
        return True


def server_in_time_window(server: "ServerItem") -> bool:
    """判断当前时刻是否在该服务器设定的运行时间窗口内。空=不限制。"""
    start_str = (server.time_window_start or "").strip()
    end_str = (server.time_window_end or "").strip()
    if not start_str and not end_str:
        return True
    now = datetime.now()
    now_minutes = now.hour * 60 + now.minute
    try:
        def to_minutes(s: str) -> int:
            h, m = map(int, s.split(":", 1))
            return h * 60 + m
        start_m = to_minutes(start_str) if start_str else 0
        end_m = to_minutes(end_str) if end_str else 23 * 60 + 59
        if start_m <= end_m:
            return start_m <= now_minutes <= end_m
        else:
            return now_minutes >= start_m or now_minutes <= end_m
    except ValueError:
        return True


def update_server_last_run(server_id: str) -> None:
    """将指定服务器的 last_run_date 更新为今天。"""
    servers = load_servers()
    today_str = datetime.now().strftime("%Y-%m-%d")
    for s in servers:
        if s.id == server_id:
            s.last_run_date = today_str
            break
    save_servers(servers)


def validate_server_input(form: Any, old: Optional["ServerItem"] = None) -> Tuple[Optional["ServerItem"], Optional[str]]:
    name = (form.get("name") or "").strip() or "未命名服务器"
    base_url = (form.get("base_url") or "").strip().rstrip("/")
    username = (form.get("username") or "").strip()
    password = form.get("password") or ""
    parent_id = (form.get("parent_id") or "").strip()
    enabled = form.get("enabled") in (True, "true", "on", 1, "1")
    verify_tls = form.get("verify_tls") in (True, "true", "on", 1, "1")
    interval_days = max(1, int(form.get("interval_days") or 1))
    time_window_start = (form.get("time_window_start") or "").strip()
    time_window_end = (form.get("time_window_end") or "").strip()

    if old and not password:
        password = old.password
    parsed = urlparse(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None, "服务器地址必须是完整 URL，例如 https://example.com:443"
    if not username:
        return None, "用户名不能为空"
    if not password:
        return None, "密码不能为空"
    item = ServerItem(
        id=old.id if old else uuid.uuid4().hex,
        name=name,
        base_url=base_url,
        username=username,
        password=password,
        parent_id=parent_id,
        enabled=enabled,
        verify_tls=verify_tls,
        interval_days=interval_days,
        time_window_start=time_window_start,
        time_window_end=time_window_end,
        last_run_date=old.last_run_date if old else "",
    )
    return item, None


def require_auth() -> Optional[Response]:
    expected_user = os.getenv("WEB_USERNAME", "").strip()
    expected_pass = os.getenv("WEB_PASSWORD", "").strip()
    if not expected_user and not expected_pass:
        return None
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Basic "):
        return Response("需要登录", 401, {"WWW-Authenticate": 'Basic realm="Emby Autoplay"'})
    try:
        raw = base64.b64decode(auth.split(" ", 1)[1]).decode("utf-8")
        user, password = raw.split(":", 1)
    except Exception:
        return Response("认证格式错误", 401, {"WWW-Authenticate": 'Basic realm="Emby Autoplay"'})
    if secrets.compare_digest(user, expected_user) and secrets.compare_digest(password, expected_pass):
        return None
    return Response("用户名或密码错误", 401, {"WWW-Authenticate": 'Basic realm="Emby Autoplay"'})


@app.before_request
def before_request_auth() -> Optional[Response]:
    return require_auth()


def cfg_for_server(server: ServerItem) -> Config:
    """将 ServerItem 转为新版 Config（Hills 模式，无需 player/user_agent 字段）"""
    return Config(
        base_url=server.base_url,
        username=server.username,
        password=server.password,
        duration_seconds=int(os.getenv("PLAY_DURATION_SECONDS", "300")),
        random_sleep_seconds=0,
        progress_interval_seconds=int(os.getenv("PROGRESS_INTERVAL_SECONDS", "10")),
        min_runtime_seconds=int(os.getenv("MIN_RUNTIME_SECONDS", "600")),
        verify_tls=server.verify_tls,
        parent_id=server.parent_id or None,
        start_from_random_position=os.getenv("START_FROM_RANDOM_POSITION", "true").lower() not in {"0", "false", "no"},
    )


def play_one_server(server: ServerItem) -> Dict[str, Any]:
    start = datetime.now().isoformat(timespec="seconds")
    safe_name = f"{server.name}（{server.base_url}）"
    app_log(f"开始播放服务器：{safe_name}")
    update_state(current_server=safe_name, last_message=f"正在播放：{safe_name}")
    player = HillsEmbyPlayer(cfg_for_server(server))
    try:
        player.run_once()
        app_log(f"服务器播放成功：{safe_name}")
        return {
            "server": server.name,
            "base_url": server.base_url,
            "ok": True,
            "started_at": start,
            "finished_at": datetime.now().isoformat(timespec="seconds"),
            "message": "播放成功",
        }
    except Exception as exc:
        app_log(f"服务器播放失败：{safe_name}，原因：{exc}")
        return {
            "server": server.name,
            "base_url": server.base_url,
            "ok": False,
            "started_at": start,
            "finished_at": datetime.now().isoformat(timespec="seconds"),
            "message": str(exc),
        }


def run_sequence(trigger: str = "manual", scheduled_random_sleep: bool = False) -> bool:
    if not playback_lock.acquire(blocking=False):
        app_log("已有播放队列正在运行，本次触发已跳过。")
        return False
    try:
        start_text = datetime.now().isoformat(timespec="seconds")
        update_state(
            running=True, trigger=trigger, started_at=start_text,
            finished_at=None, current_server=None,
            last_message="播放队列已启动。", last_result=None,
        )
        random_sleep = int(os.getenv("RANDOM_SLEEP_SECONDS", "3600")) if scheduled_random_sleep else 0
        if random_sleep > 0:
            delay = random.randint(0, random_sleep)
            app_log(f"计划任务随机等待 {delay} 秒后开始顺序播放。")
            update_state(last_message=f"计划任务随机等待 {delay} 秒后开始顺序播放。")
            time.sleep(delay)
        servers = [s for s in load_servers() if s.enabled]
        if not servers:
            message = "没有已启用的 Emby 服务器，队列结束。"
            app_log(message)
            update_state(last_message=message, last_result=[])
            return True
        results = []
        app_log(f"本次共有 {len(servers)} 个已启用服务器，将严格按列表顺序逐个播放，不并发。")
        for index, server in enumerate(servers, start=1):
            # 间隔天数检查（手动触发时跳过）
            if trigger != "manual" and not server_should_run_today(server):
                skip_msg = (
                    f"跳过服务器 [{server.name}]：间隔 {server.interval_days} 天，"
                    f"上次运行 {server.last_run_date or '从未'}，今天不在运行周期内。"
                )
                app_log(skip_msg)
                results.append({
                    "server": server.name, "base_url": server.base_url,
                    "ok": None, "skipped": True,
                    "started_at": datetime.now().isoformat(timespec="seconds"),
                    "finished_at": datetime.now().isoformat(timespec="seconds"),
                    "message": skip_msg,
                })
                continue
            # 时间窗口检查（手动触发时跳过）
            if trigger != "manual" and not server_in_time_window(server):
                win_msg = (
                    f"跳过服务器 [{server.name}]：当前时间不在运行窗口 "
                    f"{server.time_window_start or '00:00'} ~ {server.time_window_end or '23:59'} 内。"
                )
                app_log(win_msg)
                results.append({
                    "server": server.name, "base_url": server.base_url,
                    "ok": None, "skipped": True,
                    "started_at": datetime.now().isoformat(timespec="seconds"),
                    "finished_at": datetime.now().isoformat(timespec="seconds"),
                    "message": win_msg,
                })
                continue
            update_state(last_message=f"正在执行第 {index}/{len(servers)} 个服务器：{server.name}")
            result = play_one_server(server)
            if result.get("ok"):
                update_server_last_run(server.id)
            results.append(result)
            add_history(result)
        ok_count = sum(1 for x in results if x.get("ok"))
        skipped_count = sum(1 for x in results if x.get("skipped"))
        message = f"顺序播放队列完成：成功 {ok_count}/{len(results)}（跳过 {skipped_count}）。"
        app_log(message)
        update_state(last_message=message, last_result=results)
        return True
    finally:
        update_state(running=False, current_server=None, finished_at=datetime.now().isoformat(timespec="seconds"))
        playback_lock.release()


def start_sequence_thread(trigger: str, scheduled_random_sleep: bool = False) -> bool:
    if playback_lock.locked():
        return False
    thread = threading.Thread(
        target=run_sequence,
        kwargs={"trigger": trigger, "scheduled_random_sleep": scheduled_random_sleep},
        daemon=True,
    )
    thread.start()
    return True


def compute_next_schedule_ts(schedule_time: str) -> int:
    hour, minute = map(int, schedule_time.split(":", 1))
    now = datetime.now().astimezone()
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return int(target.timestamp())


def scheduler_loop() -> None:
    schedule_time = os.getenv("SCHEDULE_TIME", "07:00")
    app_log(f"后台定时器已启动：每天 {schedule_time} 触发。")
    while True:
        try:
            next_ts = compute_next_schedule_ts(schedule_time)
            update_state(next_schedule_ts=next_ts)
            sleep_seconds = max(0, next_ts - int(datetime.now().astimezone().timestamp()))
            time.sleep(sleep_seconds)
            started = start_sequence_thread("schedule", scheduled_random_sleep=True)
            if not started:
                app_log("计划触发时已有任务正在运行，本次计划跳过。")
            time.sleep(65)
        except Exception as exc:
            app_log(f"后台定时器异常：{exc}")
            time.sleep(60)


# ─────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return INDEX_HTML


@app.route("/api/status")
def api_status():
    with state_lock:
        state = dict(playback_state)
    servers = load_servers()
    state["servers"] = [asdict(s) for s in servers]
    for s in state["servers"]:
        p = s.get("password", "")
        s["password"] = p[:2] + "****" + p[-2:] if len(p) > 4 else "****"
    state["settings"] = {
        "schedule_time": os.getenv("SCHEDULE_TIME", "07:00"),
        "random_sleep": int(os.getenv("RANDOM_SLEEP_SECONDS", "3600")),
        "duration": int(os.getenv("PLAY_DURATION_SECONDS", "300")),
        "player": "Hills (RodelPlayer)",
    }
    return jsonify(state)


@app.route("/api/servers", methods=["GET"])
def api_servers():
    servers = load_servers()
    result = []
    for s in servers:
        d = asdict(s)
        p = d.get("password", "")
        d["password"] = p[:2] + "****" + p[-2:] if len(p) > 4 else "****"
        result.append(d)
    return jsonify(result)


@app.route("/api/servers", methods=["POST"])
def api_server_add():
    data = request.get_json(force=True) or {}
    item, error = validate_server_input(data)
    if error:
        return jsonify({"ok": False, "error": error}), 400
    servers = load_servers()
    servers.append(item)
    save_servers(servers)
    return jsonify({"ok": True, "id": item.id})


@app.route("/api/servers/<server_id>", methods=["PUT"])
def api_server_edit(server_id: str):
    servers = load_servers()
    old = next((s for s in servers if s.id == server_id), None)
    if not old:
        return jsonify({"ok": False, "error": "服务器不存在"}), 404
    data = request.get_json(force=True) or {}
    item, error = validate_server_input(data, old=old)
    if error:
        return jsonify({"ok": False, "error": error}), 400
    servers = [item if s.id == server_id else s for s in servers]
    save_servers(servers)
    return jsonify({"ok": True})


@app.route("/api/servers/<server_id>", methods=["DELETE"])
def api_server_delete(server_id: str):
    servers = [s for s in load_servers() if s.id != server_id]
    save_servers(servers)
    return jsonify({"ok": True})


@app.route("/api/servers/<server_id>/toggle", methods=["POST"])
def api_server_toggle(server_id: str):
    servers = load_servers()
    for s in servers:
        if s.id == server_id:
            s.enabled = not s.enabled
            break
    save_servers(servers)
    return jsonify({"ok": True})


@app.route("/api/servers/reorder", methods=["POST"])
def api_server_reorder():
    data = request.get_json(force=True) or {}
    order = data.get("order", [])
    servers = load_servers()
    id_map = {s.id: s for s in servers}
    reordered = [id_map[sid] for sid in order if sid in id_map]
    seen = set(order)
    for s in servers:
        if s.id not in seen:
            reordered.append(s)
    save_servers(reordered)
    return jsonify({"ok": True})


@app.route("/api/servers/test", methods=["POST"])
def api_server_test():
    data = request.get_json(force=True) or {}
    base_url = (data.get("base_url") or "").strip().rstrip("/")
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()
    verify_tls = data.get("verify_tls", True)
    if not base_url or not username or not password:
        return jsonify({"ok": False, "error": "缺少必填字段"}), 400
    import requests as req
    try:
        r = req.post(
            f"{base_url}/Users/AuthenticateByName",
            json={"Username": username, "Pw": password},
            headers={
                "X-Emby-Authorization": 'MediaBrowser Client="Hills", Device="Hills-PC", DeviceId="test-001", Version="1.2512.11.0"',
                "Content-Type": "application/json",
                "User-Agent": "RodelPlayer/1.2512.11.0",
            },
            timeout=10,
            verify=verify_tls,
        )
        if r.status_code == 200:
            display_name = r.json().get("User", {}).get("Name", username)
            return jsonify({"ok": True, "message": f"连接成功，用户：{display_name}"})
        else:
            return jsonify({"ok": False, "error": f"HTTP {r.status_code}：{r.text[:200]}"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/run-now", methods=["POST"])
def api_run_now():
    if start_sequence_thread("manual", scheduled_random_sleep=False):
        return jsonify({"ok": True, "message": "已开始手动顺序播放"})
    else:
        return jsonify({"ok": False, "message": "已有播放队列正在运行"})


@app.route("/api/logs")
def api_logs():
    lines_count = int(request.args.get("lines", 100))
    try:
        if APP_LOG_FILE.exists():
            with APP_LOG_FILE.open("r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
            return jsonify({"ok": True, "lines": [l.rstrip() for l in all_lines[-lines_count:]]})
    except Exception:
        pass
    return jsonify({"ok": True, "lines": []})


# ─────────────────────────────────────────────────────────────
# Frontend HTML (macOS style, i18n)
# ─────────────────────────────────────────────────────────────

INDEX_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Emby Keeper</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #f5f5f7;
    --surface: #ffffff;
    --surface2: #f5f5f7;
    --border: rgba(0,0,0,0.08);
    --border-strong: rgba(0,0,0,0.14);
    --text: #1d1d1f;
    --text2: #6e6e73;
    --text3: #aeaeb2;
    --accent: #1d1d1f;
    --accent-hover: #3a3a3c;
    --green: #34c759;
    --red: #ff3b30;
    --yellow: #ff9f0a;
    --blue: #007aff;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.06);
    --shadow-modal: 0 8px 40px rgba(0,0,0,0.14);
    --font: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif;
    --mono: "SF Mono", "Fira Code", "Menlo", monospace;
  }

  body {
    font-family: var(--font);
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    -webkit-font-smoothing: antialiased;
  }

  .app { display: flex; flex-direction: column; min-height: 100vh; }

  .navbar {
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--border);
    position: sticky; top: 0; z-index: 100;
    padding: 0 24px;
    height: 52px;
    display: flex; align-items: center; justify-content: space-between;
  }
  .navbar-brand { font-size: 17px; font-weight: 600; letter-spacing: -0.02em; }
  .navbar-sub { font-size: 12px; color: var(--text2); margin-left: 8px; font-weight: 400; }
  .navbar-right { display: flex; align-items: center; gap: 12px; }

  .main { max-width: 900px; margin: 0 auto; padding: 32px 20px 80px; width: 100%; }

  .card {
    background: var(--surface);
    border-radius: var(--radius);
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
    overflow: hidden;
    margin-bottom: 16px;
  }
  .card-header {
    padding: 16px 20px 14px;
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between;
  }
  .card-title { font-size: 15px; font-weight: 600; letter-spacing: -0.01em; }
  .card-body { padding: 20px; }

  .status-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 1px; background: var(--border); }
  .status-cell { background: var(--surface); padding: 16px 20px; }
  .status-label { font-size: 12px; color: var(--text2); text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px; font-weight: 500; }
  .status-value { font-size: 20px; font-weight: 600; letter-spacing: -0.02em; }

  .dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 6px; vertical-align: middle; }
  .dot.green { background: var(--green); box-shadow: 0 0 0 3px rgba(52,199,89,0.2); animation: pulse 2s infinite; }
  .dot.gray { background: var(--text3); }
  @keyframes pulse { 0%,100%{box-shadow:0 0 0 3px rgba(52,199,89,0.2)} 50%{box-shadow:0 0 0 6px rgba(52,199,89,0.08)} }

  .btn {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 8px 14px; border-radius: var(--radius-sm);
    font-size: 14px; font-weight: 500; font-family: var(--font);
    cursor: pointer; border: none; transition: all 0.15s ease;
    text-decoration: none; white-space: nowrap;
  }
  .btn-primary { background: var(--accent); color: #fff; }
  .btn-primary:hover { background: var(--accent-hover); }
  .btn-secondary { background: var(--surface2); color: var(--text); border: 1px solid var(--border-strong); }
  .btn-secondary:hover { background: #e8e8ed; }
  .btn-danger { background: var(--red); color: #fff; }
  .btn-ghost { background: transparent; color: var(--text2); }
  .btn-ghost:hover { background: var(--surface2); color: var(--text); }
  .btn-sm { padding: 5px 10px; font-size: 13px; }
  .btn:disabled { opacity: 0.45; cursor: not-allowed; }
  .btn-icon { width: 30px; height: 30px; padding: 0; justify-content: center; border-radius: var(--radius-sm); }

  .server-list { list-style: none; }
  .server-item {
    display: flex; align-items: center; gap: 14px;
    padding: 14px 20px;
    border-bottom: 1px solid var(--border);
    transition: background 0.1s;
  }
  .server-item:last-child { border-bottom: none; }
  .server-item:hover { background: var(--surface2); }
  .server-drag { color: var(--text3); cursor: grab; flex-shrink: 0; }
  .server-drag:active { cursor: grabbing; }
  .server-info { flex: 1; min-width: 0; }
  .server-name { font-size: 15px; font-weight: 500; letter-spacing: -0.01em; }
  .server-meta { font-size: 13px; color: var(--text2); margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .server-actions { display: flex; gap: 6px; flex-shrink: 0; }

  .badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border-radius: 6px; font-size: 12px; font-weight: 500; }
  .badge-green { background: rgba(52,199,89,0.1); color: #1a8c37; }
  .badge-gray { background: rgba(0,0,0,0.05); color: var(--text2); }
  .badge-red { background: rgba(255,59,48,0.1); color: #c0392b; }

  .toggle { position: relative; display: inline-block; width: 36px; height: 22px; }
  .toggle input { opacity: 0; width: 0; height: 0; }
  .toggle-slider {
    position: absolute; inset: 0; background: #d1d1d6; border-radius: 11px; cursor: pointer;
    transition: background 0.2s;
  }
  .toggle-slider::before {
    content: ""; position: absolute; width: 18px; height: 18px; left: 2px; top: 2px;
    background: #fff; border-radius: 50%; box-shadow: 0 1px 3px rgba(0,0,0,0.15);
    transition: transform 0.2s;
  }
  .toggle input:checked + .toggle-slider { background: var(--green); }
  .toggle input:checked + .toggle-slider::before { transform: translateX(14px); }

  .history-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .history-table th { padding: 10px 16px; text-align: left; color: var(--text2); font-weight: 500; border-bottom: 1px solid var(--border); background: var(--surface2); font-size: 12px; text-transform: uppercase; letter-spacing: 0.03em; }
  .history-table td { padding: 11px 16px; border-bottom: 1px solid var(--border); }
  .history-table tr:last-child td { border-bottom: none; }
  .history-table tr:hover td { background: var(--surface2); }

  .log-viewer {
    background: #1c1c1e; color: #e5e5ea; font-family: var(--mono);
    font-size: 12px; line-height: 1.7; padding: 16px;
    border-radius: 0 0 var(--radius) var(--radius);
    max-height: 300px; overflow-y: auto;
    white-space: pre-wrap; word-break: break-all;
  }
  .log-viewer::-webkit-scrollbar { width: 6px; }
  .log-viewer::-webkit-scrollbar-track { background: transparent; }
  .log-viewer::-webkit-scrollbar-thumb { background: #48484a; border-radius: 3px; }

  .modal-overlay {
    position: fixed; inset: 0; background: rgba(0,0,0,0.3);
    backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
    z-index: 200; display: flex; align-items: center; justify-content: center;
    opacity: 0; pointer-events: none; transition: opacity 0.2s;
  }
  .modal-overlay.open { opacity: 1; pointer-events: auto; }
  .modal {
    background: var(--surface); border-radius: 16px;
    box-shadow: var(--shadow-modal); width: 480px; max-width: calc(100vw - 32px);
    transform: scale(0.96) translateY(8px); transition: transform 0.2s;
    max-height: calc(100vh - 48px); overflow-y: auto;
  }
  .modal-overlay.open .modal { transform: scale(1) translateY(0); }
  .modal-header { padding: 20px 24px 16px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
  .modal-title { font-size: 17px; font-weight: 600; }
  .modal-body { padding: 20px 24px; }
  .modal-footer { padding: 16px 24px 20px; display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid var(--border); }

  .form-group { margin-bottom: 16px; }
  .form-label { display: block; font-size: 13px; font-weight: 500; color: var(--text); margin-bottom: 6px; }
  .form-label-hint { color: var(--text2); font-weight: 400; }
  .form-control {
    width: 100%; padding: 10px 12px; border: 1px solid var(--border-strong);
    border-radius: var(--radius-sm); font-size: 15px; font-family: var(--font);
    background: var(--surface); color: var(--text);
    transition: border-color 0.15s, box-shadow 0.15s;
    -webkit-appearance: none;
  }
  .form-control:focus { outline: none; border-color: var(--blue); box-shadow: 0 0 0 3px rgba(0,122,255,0.12); }
  .form-hint { font-size: 12px; color: var(--text2); margin-top: 5px; }
  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .form-check { display: flex; align-items: center; gap: 8px; }
  .form-check-input { width: 15px; height: 15px; accent-color: var(--accent); cursor: pointer; }

  .test-result { padding: 10px 12px; border-radius: var(--radius-sm); font-size: 13px; margin-top: 10px; display: none; }
  .test-result.ok { background: rgba(52,199,89,0.1); color: #1a8c37; }
  .test-result.fail { background: rgba(255,59,48,0.1); color: #c0392b; }

  .empty-state { text-align: center; padding: 40px 20px; }
  .empty-icon { font-size: 40px; margin-bottom: 12px; }
  .empty-title { font-size: 16px; font-weight: 600; margin-bottom: 6px; }
  .empty-desc { font-size: 14px; color: var(--text2); }

  .toast-container { position: fixed; top: 64px; right: 20px; z-index: 300; display: flex; flex-direction: column; gap: 8px; }
  .toast {
    padding: 12px 16px; border-radius: var(--radius-sm); font-size: 14px; font-weight: 500;
    box-shadow: var(--shadow-modal); min-width: 240px; max-width: 320px;
    animation: slideIn 0.25s ease;
  }
  .toast.ok { background: #1c1c1e; color: #f5f5f7; }
  .toast.err { background: var(--red); color: #fff; }
  @keyframes slideIn { from{opacity:0;transform:translateX(16px)} to{opacity:1;transform:translateX(0)} }

  .tabs { display: flex; gap: 2px; background: var(--surface2); border-radius: var(--radius-sm); padding: 3px; margin-bottom: 16px; width: fit-content; }
  .tab { padding: 6px 14px; border-radius: 6px; font-size: 13px; font-weight: 500; cursor: pointer; color: var(--text2); transition: all 0.15s; }
  .tab.active { background: var(--surface); color: var(--text); box-shadow: 0 1px 3px rgba(0,0,0,0.1); }

  .lang-btn { font-size: 13px; color: var(--text2); cursor: pointer; background: none; border: none; font-family: var(--font); padding: 4px 8px; border-radius: 6px; }
  .lang-btn:hover { background: var(--surface2); color: var(--text); }

  .countdown { font-variant-numeric: tabular-nums; }

  .server-item.dragging { opacity: 0.4; }
  .server-item.drag-over { border-top: 2px solid var(--blue); }

  @media (max-width: 600px) {
    .status-grid { grid-template-columns: 1fr 1fr; }
    .form-row { grid-template-columns: 1fr; }
    .navbar { padding: 0 16px; }
    .main { padding: 20px 12px 60px; }
  }
</style>
</head>
<body>
<div class="app">

<nav class="navbar">
  <span class="navbar-brand">Emby Keeper<span class="navbar-sub">Hills 模式</span></span>
  <div class="navbar-right">
    <button class="lang-btn" onclick="toggleLang()" id="langBtn">EN</button>
    <button class="btn btn-primary btn-sm" onclick="runNow()" id="runBtn">
      <span id="runBtnText">立即播放</span>
    </button>
  </div>
</nav>

<div class="toast-container" id="toastContainer"></div>

<main class="main">

  <div class="card">
    <div class="status-grid">
      <div class="status-cell">
        <div class="status-label" data-i18n="status">状态</div>
        <div class="status-value" id="statusValue">
          <span class="dot gray"></span><span id="statusText">空闲</span>
        </div>
        <div id="currentServerText" style="font-size:13px;color:var(--text2);margin-top:4px;"></div>
      </div>
      <div class="status-cell">
        <div class="status-label" data-i18n="nextRun">下次触发</div>
        <div class="status-value countdown" id="countdownValue">--:--:--</div>
        <div style="font-size:12px;color:var(--text2);margin-top:4px;" id="scheduleDesc"></div>
      </div>
      <div class="status-cell">
        <div class="status-label" data-i18n="lastMsg">最后消息</div>
        <div style="font-size:13px;color:var(--text2);margin-top:2px;line-height:1.5;" id="lastMessage">--</div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <span class="card-title" data-i18n="servers">Emby 账号</span>
      <button class="btn btn-secondary btn-sm" onclick="openAddModal()">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1v12M1 7h12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        <span data-i18n="addServer">添加账号</span>
      </button>
    </div>
    <ul class="server-list" id="serverList">
      <li class="empty-state" id="emptyState">
        <div class="empty-icon">📺</div>
        <div class="empty-title" data-i18n="noServers">还没有添加账号</div>
        <div class="empty-desc" data-i18n="noServersDesc">点击右上角"添加账号"开始</div>
      </li>
    </ul>
  </div>

  <div class="tabs">
    <div class="tab active" onclick="switchTab('history')" id="tabHistory" data-i18n="history">播放记录</div>
    <div class="tab" onclick="switchTab('logs')" id="tabLogs" data-i18n="logs">运行日志</div>
  </div>

  <div class="card" id="panelHistory">
    <div class="card-header">
      <span class="card-title" data-i18n="recentHistory">最近记录</span>
      <span style="font-size:12px;color:var(--text2)" id="historyCount"></span>
    </div>
    <div id="historyBody">
      <div class="empty-state"><div class="empty-desc" data-i18n="noHistory">暂无播放记录</div></div>
    </div>
  </div>

  <div class="card" id="panelLogs" style="display:none">
    <div class="card-header">
      <span class="card-title" data-i18n="runLogs">运行日志</span>
      <button class="btn btn-ghost btn-sm" onclick="loadLogs()" data-i18n="refresh">刷新</button>
    </div>
    <div class="log-viewer" id="logViewer"><span style="color:#636366">-- 点击刷新加载日志 --</span></div>
  </div>

</main>
</div>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="serverModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title" id="modalTitle">添加账号</span>
      <button class="btn btn-icon btn-ghost" onclick="closeModal()">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 3l10 10M13 3L3 13" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="editServerId">
      <div class="form-group">
        <label class="form-label" data-i18n="serverName">备注名称</label>
        <input class="form-control" id="fieldName" type="text" placeholder="例：主站" autocomplete="off">
      </div>
      <div class="form-group">
        <label class="form-label" data-i18n="serverUrl">服务器地址</label>
        <input class="form-control" id="fieldUrl" type="url" placeholder="https://example.com:8096" autocomplete="off">
        <div class="form-hint" data-i18n="serverUrlHint">包含协议和端口，例如 https://emby.example.com:8096</div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label" data-i18n="username">用户名</label>
          <input class="form-control" id="fieldUsername" type="text" autocomplete="off">
        </div>
        <div class="form-group">
          <label class="form-label">
            <span data-i18n="password">密码</span>
            <span class="form-label-hint" id="pwHint">（留空不修改）</span>
          </label>
          <input class="form-control" id="fieldPassword" type="password" autocomplete="new-password">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">
          <span data-i18n="parentId">媒体库 ID</span>
          <span class="form-label-hint" data-i18n="optional">（可选）</span>
        </label>
        <input class="form-control" id="fieldParentId" type="text" autocomplete="off">
        <div class="form-hint" data-i18n="parentIdHint">留空则从全部可访问媒体中随机选择</div>
      </div>
      <div style="display:flex;gap:20px;flex-wrap:wrap">
        <label class="form-check">
          <input class="form-check-input" id="fieldEnabled" type="checkbox" checked>
          <span data-i18n="enabled">启用</span>
        </label>
        <label class="form-check">
          <input class="form-check-input" id="fieldVerifyTls" type="checkbox" checked>
          <span data-i18n="verifyTls">校验 TLS 证书</span>
        </label>
      </div>
      <div class="form-group" style="margin-top:10px">
        <label class="form-label">
          <span data-i18n="intervalDays">运行间隔（天）</span>
          <span class="form-label-hint" data-i18n="intervalDaysHint">1=每天，2=每2天…（手动触发不受限）</span>
        </label>
        <input class="form-control" id="fieldIntervalDays" type="number" min="1" max="365" value="1" style="width:100px">
      </div>
      <div class="form-group">
        <label class="form-label">
          <span data-i18n="timeWindow">当天运行时间范围</span>
          <span class="form-label-hint" data-i18n="timeWindowHint">（留空不限）</span>
        </label>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <input class="form-control" id="fieldTimeStart" type="time" style="width:130px" placeholder="00:00">
          <span style="color:var(--text2)">~</span>
          <input class="form-control" id="fieldTimeEnd" type="time" style="width:130px" placeholder="23:59">
        </div>
        <div class="form-hint" data-i18n="timeWindowDesc">计划任务触发时，仅在此时段内实际运行此账号</div>
      </div>
      <div class="test-result" id="testResult"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="testConnection()" id="testBtn" data-i18n="testConn">测试连接</button>
      <button class="btn btn-secondary" onclick="closeModal()" data-i18n="cancel">取消</button>
      <button class="btn btn-primary" onclick="saveServer()" id="saveBtn" data-i18n="save">保存</button>
    </div>
  </div>
</div>

<script>
const I18N = {
  zh: {
    status:'状态', nextRun:'下次触发', lastMsg:'最后消息',
    servers:'Emby 账号', addServer:'添加账号',
    noServers:'还没有添加账号', noServersDesc:'点击右上角"添加账号"开始',
    history:'播放记录', logs:'运行日志',
    recentHistory:'最近记录', noHistory:'暂无播放记录',
    runLogs:'运行日志', refresh:'刷新',
    serverName:'备注名称', serverUrl:'服务器地址',
    serverUrlHint:'包含协议和端口，例如 https://emby.example.com:8096',
    username:'用户名', password:'密码',
    parentId:'媒体库 ID', optional:'（可选）',
    parentIdHint:'留空则从全部可访问媒体中随机选择',
    enabled:'启用', verifyTls:'校验 TLS 证书',
    intervalDays:'运行间隔（天）', intervalDaysHint:'1=每天，2=每2天…（手动触发不受限）',
    timeWindow:'当天运行时间范围', timeWindowHint:'（留空不限）',
    timeWindowDesc:'计划任务触发时，仅在此时段内实际运行此账号',
    testConn:'测试连接', cancel:'取消', save:'保存',
    addTitle:'添加账号', editTitle:'编辑账号',
    running:'播放中', idle:'空闲',
    runNow:'立即播放', running_btn:'运行中…',
    ok:'成功', fail:'失败',
    server:'账号', time:'时间', result:'结果', message:'说明',
    edit:'编辑', delete:'删除',
    scheduleDesc:'每天 {time} 触发 · 随机等待 {sleep}',
    pwHint:'（留空不修改）', pwHintNew:'',
    deleteConfirm:'确定删除该账号吗？',
    historyCount:'共 {n} 条',
  },
  en: {
    status:'Status', nextRun:'Next Run', lastMsg:'Last Message',
    servers:'Emby Accounts', addServer:'Add Account',
    noServers:'No accounts yet', noServersDesc:'Click "Add Account" to get started',
    history:'History', logs:'Logs',
    recentHistory:'Recent History', noHistory:'No playback records yet',
    runLogs:'Run Logs', refresh:'Refresh',
    serverName:'Display Name', serverUrl:'Server URL',
    serverUrlHint:'Include protocol and port, e.g. https://emby.example.com:8096',
    username:'Username', password:'Password',
    parentId:'Library ID', optional:'(optional)',
    parentIdHint:'Leave blank to pick from all accessible media',
    enabled:'Enabled', verifyTls:'Verify TLS',
    intervalDays:'Run Interval (days)', intervalDaysHint:'1=daily, 2=every 2 days… (manual runs ignore this)',
    timeWindow:'Time Window', timeWindowHint:'(leave blank = anytime)',
    timeWindowDesc:'Scheduled runs will only execute this account within the specified window',
    testConn:'Test Connection', cancel:'Cancel', save:'Save',
    addTitle:'Add Account', editTitle:'Edit Account',
    running:'Playing', idle:'Idle',
    runNow:'Run Now', running_btn:'Running…',
    ok:'OK', fail:'Failed',
    server:'Account', time:'Time', result:'Result', message:'Message',
    edit:'Edit', delete:'Delete',
    scheduleDesc:'Daily at {time} · random delay {sleep}',
    pwHint:'(leave blank to keep)', pwHintNew:'',
    deleteConfirm:'Delete this account?',
    historyCount:'{n} records',
  }
};
let lang = localStorage.getItem('lang') || 'zh';

function t(key, vars) {
  let s = (I18N[lang] || I18N.zh)[key] || key;
  if (vars) Object.entries(vars).forEach(([k,v]) => s = s.replace('{'+k+'}', v));
  return s;
}
function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (el.tagName === 'INPUT') el.placeholder = t(key);
    else el.textContent = t(key);
  });
  document.getElementById('langBtn').textContent = lang === 'zh' ? 'EN' : '中文';
  document.getElementById('runBtnText').textContent = t('runNow');
  document.getElementById('pwHint').textContent = t('pwHint');
}
function toggleLang() {
  lang = lang === 'zh' ? 'en' : 'zh';
  localStorage.setItem('lang', lang);
  applyI18n();
  renderAll();
}

let state = {};
let currentTab = 'history';

let pollTimer = null;
function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollStatus();
  pollTimer = setInterval(pollStatus, 3000);
}
async function pollStatus() {
  try {
    const r = await fetch('/api/status');
    state = await r.json();
    renderAll();
  } catch(e) {}
}
function renderAll() { renderStatus(); renderServers(); renderHistory(); }

let countdownTimer = null;
function renderStatus() {
  const running = state.running;
  document.getElementById('statusValue').innerHTML = running
    ? `<span class="dot green"></span><span>${t('running')}</span>`
    : `<span class="dot gray"></span><span>${t('idle')}</span>`;
  document.getElementById('currentServerText').textContent = state.current_server || '';
  document.getElementById('lastMessage').textContent = state.last_message || '--';
  const settings = state.settings || {};
  const sleep = settings.random_sleep || 0;
  const sleepStr = sleep >= 3600 ? Math.round(sleep/3600)+'h' : sleep+'s';
  document.getElementById('scheduleDesc').textContent =
    t('scheduleDesc', {time: settings.schedule_time || '--:--', sleep: sleepStr});
  const runBtn = document.getElementById('runBtn');
  document.getElementById('runBtnText').textContent = running ? t('running_btn') : t('runNow');
  runBtn.disabled = running;
  if (countdownTimer) clearInterval(countdownTimer);
  if (state.next_schedule_ts) {
    const tick = () => {
      const diff = Math.max(0, state.next_schedule_ts - Math.floor(Date.now()/1000));
      const h = String(Math.floor(diff/3600)).padStart(2,'0');
      const m = String(Math.floor((diff%3600)/60)).padStart(2,'0');
      const s = String(diff%60).padStart(2,'0');
      document.getElementById('countdownValue').textContent = `${h}:${m}:${s}`;
    };
    tick();
    countdownTimer = setInterval(tick, 1000);
  }
}

let dragSrc = null;
function renderServers() {
  const servers = state.servers || [];
  const list = document.getElementById('serverList');
  const empty = document.getElementById('emptyState');
  if (!servers.length) {
    list.innerHTML = '';
    list.appendChild(empty);
    empty.style.display = '';
    return;
  }
  empty.style.display = 'none';
  list.innerHTML = servers.map((s,i) => `
    <li class="server-item" draggable="true" data-id="${s.id}"
      ondragstart="dsDragStart(event,'${s.id}')"
      ondragover="dsDragOver(event)"
      ondrop="dsDrop(event,'${s.id}')"
      ondragend="dsDragEnd(event)">
      <span class="server-drag" title="${lang==='zh'?'拖拽排序':'Drag to reorder'}">
        <svg width="12" height="16" viewBox="0 0 12 16" fill="currentColor"><circle cx="3" cy="3" r="1.5"/><circle cx="9" cy="3" r="1.5"/><circle cx="3" cy="8" r="1.5"/><circle cx="9" cy="8" r="1.5"/><circle cx="3" cy="13" r="1.5"/><circle cx="9" cy="13" r="1.5"/></svg>
      </span>
      <div class="server-info">
        <div class="server-name">${escHtml(s.name)}</div>
        <div class="server-meta">${escHtml(s.base_url)} · ${escHtml(s.username)}</div>
        <div class="server-meta" style="font-size:11px;color:var(--text2);margin-top:2px">${
          (() => {
            const parts = [];
            if (s.interval_days > 1) parts.push((lang==='zh'?'每':'every ')+s.interval_days+(lang==='zh'?' 天':'d'));
            if (s.time_window_start || s.time_window_end) parts.push((s.time_window_start||'00:00')+'~'+(s.time_window_end||'23:59'));
            if (s.last_run_date) parts.push((lang==='zh'?'上次:':'last:')+s.last_run_date);
            return parts.join(' · ');
          })()
        }</div>
      </div>
      <div>
        <label class="toggle">
          <input type="checkbox" ${s.enabled?'checked':''} onchange="toggleServer('${s.id}',this)">
          <span class="toggle-slider"></span>
        </label>
      </div>
      <div class="server-actions">
        <button class="btn btn-secondary btn-sm" onclick="openEditModal('${s.id}')">${t('edit')}</button>
        <button class="btn btn-ghost btn-sm" onclick="deleteServer('${s.id}')" style="color:var(--red)">${t('delete')}</button>
      </div>
    </li>
  `).join('');
}

function dsDragStart(e, id) {
  dragSrc = id;
  e.currentTarget.classList.add('dragging');
  e.dataTransfer.effectAllowed = 'move';
}
function dsDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  document.querySelectorAll('.server-item').forEach(el => el.classList.remove('drag-over'));
  e.currentTarget.classList.add('drag-over');
}
function dsDrop(e, targetId) {
  e.preventDefault();
  if (!dragSrc || dragSrc === targetId) return;
  const servers = state.servers || [];
  const order = servers.map(s => s.id);
  const from = order.indexOf(dragSrc);
  const to = order.indexOf(targetId);
  order.splice(from, 1);
  order.splice(to, 0, dragSrc);
  fetch('/api/servers/reorder', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({order})})
    .then(()=>pollStatus());
}
function dsDragEnd(e) {
  e.currentTarget.classList.remove('dragging');
  document.querySelectorAll('.server-item').forEach(el => el.classList.remove('drag-over'));
  dragSrc = null;
}

async function toggleServer(id, cb) {
  const en = cb.checked;
  try {
    await fetch(`/api/servers/${id}/toggle`, {method:'POST'});
    pollStatus();
  } catch(e) { cb.checked = !en; }
}
async function deleteServer(id) {
  if (!confirm(t('deleteConfirm'))) return;
  await fetch(`/api/servers/${id}`, {method:'DELETE'});
  toast(lang==='zh'?'已删除':'Deleted');
  pollStatus();
}

function openAddModal() {
  document.getElementById('modalTitle').textContent = t('addTitle');
  document.getElementById('editServerId').value = '';
  ['fieldName','fieldUrl','fieldUsername','fieldPassword','fieldParentId'].forEach(id => {
    document.getElementById(id).value = '';
  });
  document.getElementById('fieldEnabled').checked = true;
  document.getElementById('fieldVerifyTls').checked = true;
  document.getElementById('fieldIntervalDays').value = 1;
  document.getElementById('fieldTimeStart').value = '';
  document.getElementById('fieldTimeEnd').value = '';
  document.getElementById('pwHint').textContent = t('pwHintNew');
  document.getElementById('testResult').style.display = 'none';
  openModal();
}
function openEditModal(id) {
  const s = (state.servers||[]).find(x=>x.id===id);
  if (!s) return;
  document.getElementById('modalTitle').textContent = t('editTitle');
  document.getElementById('editServerId').value = id;
  document.getElementById('fieldName').value = s.name;
  document.getElementById('fieldUrl').value = s.base_url;
  document.getElementById('fieldUsername').value = s.username;
  document.getElementById('fieldPassword').value = '';
  document.getElementById('fieldParentId').value = s.parent_id || '';
  document.getElementById('fieldEnabled').checked = s.enabled;
  document.getElementById('fieldVerifyTls').checked = s.verify_tls !== false;
  document.getElementById('fieldIntervalDays').value = s.interval_days || 1;
  document.getElementById('fieldTimeStart').value = s.time_window_start || '';
  document.getElementById('fieldTimeEnd').value = s.time_window_end || '';
  document.getElementById('pwHint').textContent = t('pwHint');
  document.getElementById('testResult').style.display = 'none';
  openModal();
}
function openModal() { document.getElementById('serverModal').classList.add('open'); }
function closeModal() { document.getElementById('serverModal').classList.remove('open'); }
document.getElementById('serverModal').addEventListener('click', e => { if (e.target===e.currentTarget) closeModal(); });

async function saveServer() {
  const id = document.getElementById('editServerId').value;
  const body = {
    name: document.getElementById('fieldName').value,
    base_url: document.getElementById('fieldUrl').value,
    username: document.getElementById('fieldUsername').value,
    password: document.getElementById('fieldPassword').value,
    parent_id: document.getElementById('fieldParentId').value,
    enabled: document.getElementById('fieldEnabled').checked,
    verify_tls: document.getElementById('fieldVerifyTls').checked,
    interval_days: parseInt(document.getElementById('fieldIntervalDays').value) || 1,
    time_window_start: document.getElementById('fieldTimeStart').value,
    time_window_end: document.getElementById('fieldTimeEnd').value,
  };
  const url = id ? `/api/servers/${id}` : '/api/servers';
  const method = id ? 'PUT' : 'POST';
  const btn = document.getElementById('saveBtn');
  btn.disabled = true;
  try {
    const r = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
    const data = await r.json();
    if (data.ok) { closeModal(); toast(lang==='zh'?'已保存':'Saved'); pollStatus(); }
    else toast(data.error || 'Error', true);
  } finally { btn.disabled = false; }
}

async function testConnection() {
  const btn = document.getElementById('testBtn');
  const resultEl = document.getElementById('testResult');
  const body = {
    base_url: document.getElementById('fieldUrl').value,
    username: document.getElementById('fieldUsername').value,
    password: document.getElementById('fieldPassword').value || '____placeholder____',
    verify_tls: document.getElementById('fieldVerifyTls').checked,
  };
  btn.disabled = true;
  resultEl.style.display = 'none';
  try {
    const r = await fetch('/api/servers/test', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
    const data = await r.json();
    resultEl.textContent = data.ok ? `✓ ${data.message}` : `✗ ${data.error}`;
    resultEl.className = 'test-result ' + (data.ok ? 'ok' : 'fail');
    resultEl.style.display = 'block';
  } finally { btn.disabled = false; }
}

async function runNow() {
  const btn = document.getElementById('runBtn');
  btn.disabled = true;
  try {
    const r = await fetch('/api/run-now', {method:'POST'});
    const data = await r.json();
    toast(data.message);
    pollStatus();
  } finally { setTimeout(()=>{ btn.disabled = state.running; }, 1500); }
}

function renderHistory() {
  const history = state.history || [];
  const body = document.getElementById('historyBody');
  const count = document.getElementById('historyCount');
  count.textContent = history.length ? t('historyCount',{n:history.length}) : '';
  if (!history.length) {
    body.innerHTML = `<div class="empty-state"><div class="empty-desc">${t('noHistory')}</div></div>`;
    return;
  }
  body.innerHTML = `<table class="history-table">
    <thead><tr>
      <th>${t('time')}</th><th>${t('server')}</th><th>${t('result')}</th><th>${t('message')}</th>
    </tr></thead>
    <tbody>${history.map(h=>`<tr>
      <td style="white-space:nowrap;color:var(--text2)">${h.finished_at||''}</td>
      <td>${escHtml(h.server||'')}</td>
      <td>${h.ok?`<span class="badge badge-green">✓ ${t('ok')}</span>`:`<span class="badge badge-red">✗ ${t('fail')}</span>`}</td>
      <td style="color:var(--text2);font-size:13px">${escHtml(h.message||'')}</td>
    </tr>`).join('')}</tbody>
  </table>`;
}

async function loadLogs() {
  const el = document.getElementById('logViewer');
  el.textContent = lang==='zh'?'加载中…':'Loading…';
  try {
    const r = await fetch('/api/logs?lines=200');
    const data = await r.json();
    el.textContent = (data.lines||[]).join('\n') || (lang==='zh'?'（暂无日志）':'(no logs yet)');
    el.scrollTop = el.scrollHeight;
  } catch(e) { el.textContent = 'Error loading logs'; }
}

function switchTab(tab) {
  currentTab = tab;
  document.getElementById('panelHistory').style.display = tab==='history'?'':'none';
  document.getElementById('panelLogs').style.display = tab==='logs'?'':'none';
  document.getElementById('tabHistory').className = 'tab' + (tab==='history'?' active':'');
  document.getElementById('tabLogs').className = 'tab' + (tab==='logs'?' active':'');
  if (tab==='logs') loadLogs();
}

function toast(msg, isErr=false) {
  const el = document.createElement('div');
  el.className = 'toast ' + (isErr?'err':'ok');
  el.textContent = msg;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(()=>el.remove(), 3200);
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

applyI18n();
startPolling();
</script>
</body>
</html>"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=os.getenv("WEB_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("WEB_LISTEN_PORT", "8080")))
    parser.add_argument("--once", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    if args.once or os.getenv("RUN_MODE") == "once":
        ok = run_sequence("once", scheduled_random_sleep=False)
        return 0 if ok else 1
    scheduler = threading.Thread(target=scheduler_loop, daemon=True)
    scheduler.start()
    app_log(f"网页服务启动：http://0.0.0.0:{args.port}")
    app.run(host=args.host, port=args.port, threaded=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
