#!/usr/bin/env python3
"""
Emby 自动保号脚本 - Hills (RodelPlayer) 模拟版

模拟 Hills Lite (RodelPlayer/1.2512.11.0) 的真实请求行为：
1. 使用 RodelPlayer User-Agent 登录
2. 完整的 PlaybackInfo 握手
3. 模拟 Hills 的 Range 请求拉流模式（探头 → 跳到起始点 → 持续缓冲）
4. 随机抖动的进度上报
5. 偶尔模拟暂停
"""

from __future__ import annotations

import argparse
import os
import random
import sys
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlencode

import requests

TICKS_PER_SECOND = 10_000_000
DEFAULT_DEVICE_ID_FILE = Path.home() / ".emby_hills_device_id"

# Hills Lite (Windows) 真实客户端信息
HILLS_CLIENT = {
    "user_agent": "RodelPlayer/1.2512.11.0",
    "client_name": "Hills",
    "client_version": "1.2512.11.0",
    "device_name": "Hills-PC",
}

# 兼容旧版 webapp 使用的 DEVICE_PROFILES（保留以免导入报错）
DEVICE_PROFILES = [
    {"user_agent": HILLS_CLIENT["user_agent"], "device_name": HILLS_CLIENT["device_name"], "client_version": HILLS_CLIENT["client_version"]},
]

# Range 请求每个 chunk 大小范围 (bytes)
CHUNK_MIN = 512 * 1024       # 512 KB
CHUNK_MAX = 2 * 1024 * 1024  # 2 MB


def log(message: str) -> None:
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}", flush=True)


def load_env_file(path: str | None) -> None:
    if not path:
        return
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"配置文件不存在：{p}")
    for raw_line in p.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def get_device_id() -> str:
    """获取固定 Device ID，首次运行时生成并保存"""
    configured = os.getenv("EMBY_DEVICE_ID")
    if configured:
        return configured
    p = DEFAULT_DEVICE_ID_FILE
    if p.exists():
        return p.read_text(encoding="utf-8").strip()
    device_id = str(uuid.uuid4()).upper()
    p.write_text(device_id + "\n", encoding="utf-8")
    try:
        p.chmod(0o600)
    except OSError:
        pass
    log(f"已生成新 Device ID：{device_id}（保存于 {p}）")
    return device_id


@dataclass
class Config:
    base_url: str
    username: str
    password: str
    duration_seconds: int
    random_sleep_seconds: int
    progress_interval_seconds: int
    min_runtime_seconds: int
    verify_tls: bool
    parent_id: str | None
    start_from_random_position: bool

    @classmethod
    def from_env_and_args(cls, args: argparse.Namespace) -> "Config":
        base_url = (os.getenv("EMBY_URL") or "").rstrip("/")
        username = os.getenv("EMBY_USERNAME") or ""
        password = os.getenv("EMBY_PASSWORD") or ""
        if not base_url or not username or not password:
            raise SystemExit("必须设置 EMBY_URL、EMBY_USERNAME、EMBY_PASSWORD。")
        return cls(
            base_url=base_url,
            username=username,
            password=password,
            duration_seconds=args.duration or int(os.getenv("PLAY_DURATION_SECONDS", "300")),
            random_sleep_seconds=args.random_sleep if args.random_sleep is not None else int(os.getenv("RANDOM_SLEEP_SECONDS", "0")),
            progress_interval_seconds=int(os.getenv("PROGRESS_INTERVAL_SECONDS", "10")),
            min_runtime_seconds=int(os.getenv("MIN_RUNTIME_SECONDS", "600")),
            verify_tls=os.getenv("VERIFY_TLS", "true").lower() not in {"0", "false", "no"},
            parent_id=os.getenv("PARENT_ID") or None,
            start_from_random_position=os.getenv("START_FROM_RANDOM_POSITION", "true").lower() not in {"0", "false", "no"},
        )


class HillsEmbyPlayer:
    """模拟 Hills Lite (RodelPlayer) 的完整播放行为"""

    def __init__(self, config: Config) -> None:
        self.cfg = config
        self.device_id = get_device_id()
        self.volume_level = random.randint(40, 85)
        self.session = requests.Session()

        auth_header = (
            f'MediaBrowser Client="{HILLS_CLIENT["client_name"]}", '
            f'Device="{HILLS_CLIENT["device_name"]}", '
            f'DeviceId="{self.device_id}", '
            f'Version="{HILLS_CLIENT["client_version"]}"'
        )
        self.session.headers.update({
            "User-Agent": HILLS_CLIENT["user_agent"],
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
            "Accept-Encoding": "gzip, deflate, br",
            "Content-Type": "application/json",
            "X-Emby-Authorization": auth_header,
            "Connection": "keep-alive",
        })
        self.user_id: str = ""
        self.token: str = ""

    def request(self, method: str, path: str, **kwargs: Any) -> requests.Response:
        url = f"{self.cfg.base_url}{path}"
        kwargs.setdefault("timeout", 30)
        kwargs.setdefault("verify", self.cfg.verify_tls)
        r = self.session.request(method, url, **kwargs)
        if r.status_code >= 400:
            raise RuntimeError(f"{method} {path} 失败：HTTP {r.status_code} {r.text[:300]}")
        return r

    # ── 认证 ────────────────────────────────────────────────

    def authenticate(self) -> None:
        log("正在以 Hills 身份登录 Emby...")
        r = self.request(
            "POST", "/Users/AuthenticateByName",
            json={"Username": self.cfg.username, "Pw": self.cfg.password}
        )
        data = r.json()
        self.token = data["AccessToken"]
        self.user_id = data["User"]["Id"]
        self.session.headers.update({"X-Emby-Token": self.token})
        log(f"登录成功，UserId={self.user_id}")

    # ── 选片 ────────────────────────────────────────────────

    def select_random_item(self) -> Dict[str, Any]:
        min_ticks = max(
            self.cfg.min_runtime_seconds,
            self.cfg.duration_seconds + 60
        ) * TICKS_PER_SECOND

        params = {
            "Recursive": "true",
            "IncludeItemTypes": "Movie,Episode,Video",
            "Fields": "MediaSources,RunTimeTicks,Path,Overview,SeriesName",
            "SortBy": "Random",
            "Limit": "50",
        }
        if self.cfg.parent_id:
            params["ParentId"] = self.cfg.parent_id

        log("正在随机选择可播放视频...")
        r = self.request("GET", f"/Users/{self.user_id}/Items", params=params)
        items = r.json().get("Items", [])
        candidates = [
            x for x in items
            if int(x.get("RunTimeTicks") or 0) >= min_ticks
        ]
        if not candidates:
            candidates = [x for x in items if int(x.get("RunTimeTicks") or 0) > 0]
        if not candidates:
            candidates = items
        if not candidates:
            raise RuntimeError("未找到可播放的视频条目。")

        item = random.choice(candidates)
        runtime = int(item.get("RunTimeTicks") or 0) // TICKS_PER_SECOND
        log(f"选中：{item.get('Name')}（{item.get('Type')}，时长约 {runtime}s）")
        return item

    # ── PlaybackInfo ─────────────────────────────────────────

    def get_playback_info(
        self, item: Dict[str, Any], start_ticks: int
    ) -> Tuple[str, str, Optional[str], int]:
        """返回 (media_source_id, play_session_id, container, file_size)"""
        item_id = item["Id"]
        bitrate = random.randint(10_000_000, 40_000_000)
        params = {
            "UserId": self.user_id,
            "StartTimeTicks": str(start_ticks),
            "IsPlayback": "true",
            "AutoOpenLiveStream": "true",
            "MaxStreamingBitrate": str(bitrate),
        }
        try:
            r = self.request("GET", f"/Items/{item_id}/PlaybackInfo", params=params)
            info = r.json()
            play_session_id = info.get("PlaySessionId") or uuid.uuid4().hex
            media_sources = info.get("MediaSources") or item.get("MediaSources") or []
            media_source = media_sources[0] if media_sources else {}
            media_source_id = media_source.get("Id") or f"mediasource_{item_id}"
            container = media_source.get("Container")
            file_size = int(media_source.get("Size") or 0)
            log(f"PlaybackInfo 获取成功，SessionId={play_session_id}，文件大小={file_size} bytes")
            return media_source_id, play_session_id, container, file_size
        except Exception as exc:
            log(f"PlaybackInfo 获取失败，使用条目自带媒体源：{exc}")
            media_sources = item.get("MediaSources") or []
            media_source = media_sources[0] if media_sources else {}
            media_source_id = media_source.get("Id") or f"mediasource_{item_id}"
            return media_source_id, uuid.uuid4().hex, media_source.get("Container"), 0

    # ── 状态上报 ─────────────────────────────────────────────

    def report_playing(
        self, item_id: str, media_source_id: str,
        play_session_id: str, position_ticks: int
    ) -> None:
        body = {
            "ItemId": item_id,
            "MediaSourceId": media_source_id,
            "PlaySessionId": play_session_id,
            "PlayMethod": "DirectPlay",
            "PositionTicks": position_ticks,
            "CanSeek": True,
            "IsPaused": False,
            "IsMuted": False,
            "VolumeLevel": self.volume_level,
            "RepeatMode": "RepeatNone",
            "SubtitleStreamIndex": -1,
            "AudioStreamIndex": 1,
        }
        self.request("POST", "/Sessions/Playing", json=body)
        log("已上报播放开始（DirectPlay）")

    def report_progress(
        self, item_id: str, media_source_id: str,
        play_session_id: str, position_ticks: int,
        is_paused: bool = False
    ) -> None:
        body = {
            "ItemId": item_id,
            "MediaSourceId": media_source_id,
            "PlaySessionId": play_session_id,
            "PlayMethod": "DirectPlay",
            "PositionTicks": position_ticks,
            "CanSeek": True,
            "IsPaused": is_paused,
            "IsMuted": False,
            "VolumeLevel": self.volume_level,
            "EventName": "TimeUpdate",
            "SubtitleStreamIndex": -1,
            "AudioStreamIndex": 1,
        }
        self.request("POST", "/Sessions/Playing/Progress", json=body)

    def report_stopped(
        self, item_id: str, media_source_id: str,
        play_session_id: str, position_ticks: int
    ) -> None:
        body = {
            "ItemId": item_id,
            "MediaSourceId": media_source_id,
            "PlaySessionId": play_session_id,
            "PositionTicks": position_ticks,
        }
        self.request("POST", "/Sessions/Playing/Stopped", json=body)
        log("已上报播放停止")

    # ── 流地址 ───────────────────────────────────────────────

    def stream_url(
        self, item_id: str, media_source_id: str,
        start_ticks: int, container: Optional[str]
    ) -> str:
        ext = container if container else "mp4"
        params = {
            "Static": "true",
            "mediaSourceId": media_source_id,
            "DeviceId": self.device_id,
            "api_key": self.token,
        }
        if start_ticks:
            params["StartTimeTicks"] = str(start_ticks)
        return f"{self.cfg.base_url}/Videos/{item_id}/stream.{ext}?{urlencode(params)}"

    # ── Hills Range 请求模拟 ──────────────────────────────────

    def _range_request(self, url: str, start: int, end: Optional[int] = None) -> int:
        """发一个 Range 请求，只读取少量数据模拟缓冲。返回实际读取字节数。"""
        range_header = f"bytes={start}-" if end is None else f"bytes={start}-{end}"
        headers = {
            "Range": range_header,
            "User-Agent": HILLS_CLIENT["user_agent"],
            "Referer": self.cfg.base_url + "/",
        }
        if self.token:
            headers["X-Emby-Token"] = self.token

        try:
            r = self.session.get(
                url, headers=headers,
                stream=True,
                timeout=20,
                verify=self.cfg.verify_tls,
            )
            if r.status_code not in (200, 206):
                log(f"Range 请求异常状态码：{r.status_code}")
                return 0

            read_limit = random.randint(CHUNK_MIN, CHUNK_MAX)
            read_bytes = 0
            for chunk in r.iter_content(chunk_size=65536):
                if not chunk:
                    break
                read_bytes += len(chunk)
                if read_bytes >= read_limit:
                    break
            r.close()
            return read_bytes
        except Exception as exc:
            log(f"Range 请求失败（可忽略）：{exc}")
            return 0

    def _probe_file_size(self, url: str) -> int:
        """通过 HEAD 请求获取文件大小"""
        try:
            r = self.session.head(url, timeout=10, verify=self.cfg.verify_tls,
                                  headers={"User-Agent": HILLS_CLIENT["user_agent"]})
            cl = r.headers.get("Content-Length") or r.headers.get("content-length")
            if cl:
                size = int(cl)
                log(f"探测文件大小：{size} bytes ({size/1024/1024:.1f} MB)")
                return size
        except Exception as exc:
            log(f"探测文件大小失败：{exc}")
        return 0

    def simulate_hills_streaming(
        self,
        url: str,
        item_id: str,
        media_source_id: str,
        play_session_id: str,
        start_ticks: int,
        start_seconds: int,
        file_size: int,
    ) -> None:
        """
        模拟 Hills 真实拉流行为：
        1. Range: 0-  （探测文件头）
        2. 跳到播放起始位置的字节偏移
        3. 持续按播放进度请求后续 chunk
        4. 偶尔模拟暂停
        """
        duration = self.cfg.duration_seconds + random.randint(-30, 45)
        duration = max(120, duration)

        pause_at = (
            random.randint(int(duration * 0.25), int(duration * 0.65))
            if random.random() < 0.35 else None
        )
        pause_duration = random.randint(4, 15) if pause_at else 0

        # 如果没有文件大小，尝试 HEAD 探测
        if file_size == 0:
            file_size = self._probe_file_size(url)

        log(f"开始模拟 Hills 拉流，时长约 {duration}s，起始位置 {start_seconds}s")

        # Step 1: 探测文件头
        log("Hills 行为：发送探测请求 Range: 0-")
        self._range_request(url, 0)
        time.sleep(random.uniform(0.3, 0.8))

        # Step 2: 跳到播放起始字节位置
        if file_size > 0 and start_seconds > 0:
            runtime_seconds = max(self.cfg.min_runtime_seconds, duration + 300)
            byte_offset = int(file_size * (start_seconds / max(runtime_seconds, 1)))
            byte_offset = max(0, byte_offset - random.randint(0, 512 * 1024))
            log(f"Hills 行为：跳到起始字节 Range: {byte_offset}-")
            self._range_request(url, byte_offset)
            time.sleep(random.uniform(0.2, 0.6))
        elif start_seconds > 0:
            estimated_offset = start_seconds * random.randint(200_000, 500_000)
            log(f"Hills 行为：估算跳转 Range: {estimated_offset}-")
            self._range_request(url, estimated_offset)
            time.sleep(random.uniform(0.2, 0.6))

        # Step 3: 持续拉流循环
        play_start = time.monotonic()
        next_progress = 0.0
        paused = False
        current_byte_pos = 0
        bitrate_bps = random.randint(2_000_000, 6_000_000)
        bytes_per_second = bitrate_bps // 8

        while True:
            elapsed = time.monotonic() - play_start
            if elapsed >= duration:
                break

            # 模拟暂停
            if pause_at and not paused and elapsed >= pause_at:
                paused = True
                pos = start_ticks + int(elapsed * TICKS_PER_SECOND)
                log(f"模拟暂停 {pause_duration}s（位置 {int(elapsed)}s）")
                self.report_progress(item_id, media_source_id, play_session_id, pos, is_paused=True)
                time.sleep(pause_duration)
                self.report_progress(item_id, media_source_id, play_session_id, pos, is_paused=False)
                log("模拟继续播放")

            # Range 拉流，Hills 大约每 2-5 秒发一次请求
            chunk_interval = random.uniform(2.0, 5.0)
            current_byte_pos += int(bytes_per_second * chunk_interval)
            if file_size > 0:
                current_byte_pos = min(current_byte_pos, file_size - 1024)

            log(f"Hills 拉流中：elapsed={int(elapsed)}s，Range: {current_byte_pos}-")
            self._range_request(url, current_byte_pos)

            # 上报播放进度（随机间隔 8-16 秒）
            if elapsed >= next_progress:
                pos = start_ticks + int(elapsed * TICKS_PER_SECOND)
                self.report_progress(item_id, media_source_id, play_session_id, pos)
                log(f"进度上报：{int(elapsed)}/{duration}s")
                next_progress += random.randint(8, 16)

            wait = max(0.5, chunk_interval - random.uniform(0, 1))
            time.sleep(wait)

        final_elapsed = min(duration, int(time.monotonic() - play_start))
        final_pos = start_ticks + final_elapsed * TICKS_PER_SECOND
        self.report_progress(item_id, media_source_id, play_session_id, final_pos)
        log(f"Hills 拉流结束，实际播放 {final_elapsed}s")

    # ── 主流程 ───────────────────────────────────────────────

    def run_once(self) -> None:
        if self.cfg.random_sleep_seconds > 0:
            delay = random.randint(0, self.cfg.random_sleep_seconds)
            log(f"随机等待 {delay}s 后开始播放")
            time.sleep(delay)

        self.authenticate()
        item = self.select_random_item()
        item_id = item["Id"]
        runtime_ticks = int(item.get("RunTimeTicks") or 0)

        if self.cfg.start_from_random_position:
            max_start = max(0, runtime_ticks // TICKS_PER_SECOND - self.cfg.duration_seconds - 60)
            start_seconds = random.randint(0, max_start) if max_start > 0 else 0
        else:
            start_seconds = 0
        start_ticks = start_seconds * TICKS_PER_SECOND
        log(f"从视频第 {start_seconds}s 开始播放")

        media_source_id, play_session_id, container, file_size = self.get_playback_info(item, start_ticks)
        url = self.stream_url(item_id, media_source_id, start_ticks, container)

        try:
            self.report_playing(item_id, media_source_id, play_session_id, start_ticks)
            self.simulate_hills_streaming(
                url, item_id, media_source_id, play_session_id,
                start_ticks, start_seconds, file_size,
            )
        finally:
            try:
                final_ticks = start_ticks + self.cfg.duration_seconds * TICKS_PER_SECOND
                self.report_stopped(item_id, media_source_id, play_session_id, final_ticks)
            except Exception as exc:
                log(f"停止上报失败：{exc}")

        log("本次保号任务完成。")


# ── 向后兼容别名（供 emby_webapp.py 导入）────────────────────
EmbyAutoPlayer = HillsEmbyPlayer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Emby 保号脚本（Hills 模拟版）")
    parser.add_argument("--env-file", default=None)
    parser.add_argument("--duration", type=int, default=None)
    parser.add_argument("--random-sleep", type=int, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    load_env_file(args.env_file)
    cfg = Config.from_env_and_args(args)
    player = HillsEmbyPlayer(cfg)
    try:
        player.run_once()
        return 0
    except Exception as exc:
        log(f"任务失败：{exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
